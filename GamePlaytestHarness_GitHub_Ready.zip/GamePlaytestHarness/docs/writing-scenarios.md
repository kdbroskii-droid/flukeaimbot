# Writing Scenarios

The current repository provides the scenario runner framework.

A scenario should:

1. Set up the test world through the game's test/public APIs.
2. Tick the harness until a timeout or completion condition.
3. Record assertions such as movement distance, placement success, edit completion, or hit timing.
4. Write decision and assertion telemetry.

Add your game's scenario definitions to `ScenarioRunner` or split them into dedicated scenario classes as the project grows.
