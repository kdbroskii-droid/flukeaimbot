# Adapter Guide

Open `src/GamePlaytestHarness/GameAdapter.cs`.

Every method that needs integration with the game is marked with a `TODO:` comment.
Replace the placeholder body with calls to your game's public controller APIs.

Examples of intended mappings:

- `MoveForward()` -> player controller forward movement API
- `Jump()` -> player controller jump API
- `Fire()` -> weapon controller fire API
- `PlaceBuild()` -> build controller placement API
- `EnterEdit()` -> edit controller enter API

The harness itself should not call OS input APIs.
