# Architecture

- `GameAdapter` is the only bridge between the harness and the game's public APIs.
- `Context` captures a per-tick world snapshot.
- `ScenarioRunner` coordinates repeatable QA scenarios.
- `AimTelemetry` records targeting and camera diagnostics.
- `FireEventTester` validates scheduled fire events through the game's own API.
- Validators probe movement, combat, building, editing, resources, and rush behavior.
- `DecisionLogger` records decisions for CSV analysis.
