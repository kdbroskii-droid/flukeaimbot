# GamePlaytestHarness

Automated playtesting and QA harness for [game name].

## What it does

Internal QA tooling for driving your game's own public controller APIs through repeatable scenarios, collecting telemetry, and validating combat, movement, building, and editing systems.

## What it does not do

- No OS keyboard or mouse simulation
- No external process interaction
- All game calls route through `GameAdapter`

## Hotkeys

| Hotkey | Action |
|---|---|
| Alt+0 | Start/stop scenario runner |
| Alt+1 | Toggle aim telemetry overlay |
| Alt+2 | Toggle fire-event logging |
| Alt+9 | Toggle aggressive test profile |

## Build

```bash
dotnet restore
dotnet build
dotnet run
```

## Adapter

Wire your own game's public APIs in `GameAdapter.cs`. Every integration point is marked with `TODO:`.

## Architecture

- GameAdapter: game API bridge
- Context: per-tick state snapshot
- AimTelemetry: targeting/camera diagnostics
- ScenarioRunner: scenario execution
- Validators: combat, build, edit, movement, resources
- DecisionLogger: telemetry output

## Internal use

For internal use with [game name] only.

## License

MIT.


## GitHub Actions build artifact

Push to `main`, open the **Actions** tab, select the latest **Build GamePlaytestHarness** run, and download:

`GamePlaytestHarness-win-x64`

The artifact contains the published Windows x64 application files.
