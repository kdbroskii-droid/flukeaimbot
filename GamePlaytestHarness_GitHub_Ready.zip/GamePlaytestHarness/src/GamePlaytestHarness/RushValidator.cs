namespace GamePlaytestHarness;

public sealed class RushValidator
{
    private readonly IActionAPI _actions;

    public RushValidator(IActionAPI actions) => _actions = actions;

    public void Tick(Context context)
    {
        if (context.NearestEnemy is null)
            return;

        _actions.MoveForward();
        _actions.Sprint(true);

        if (context.NearestEnemyDistance < 20f)
            _actions.Jump();
    }
}
