using System.Numerics;

namespace GamePlaytestHarness;

public sealed class MovementProbe
{
    private Vector3 _startPosition;
    private double _startTime;

    public void Begin(Context context)
    {
        _startPosition = context.PlayerPosition;
        _startTime = context.TimestampSeconds;
    }

    public MovementResult End(Context context)
    {
        return new MovementResult(
            Vector3.Distance(_startPosition, context.PlayerPosition),
            context.TimestampSeconds - _startTime);
    }

    public readonly record struct MovementResult(float Distance, double ElapsedSeconds);
}
