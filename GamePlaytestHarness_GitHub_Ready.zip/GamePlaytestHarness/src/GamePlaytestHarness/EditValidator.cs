namespace GamePlaytestHarness;

public sealed class EditValidator
{
    private readonly IActionAPI _actions;
    public EditValidator(IActionAPI actions) => _actions = actions;

    public bool ValidateQuadEdit(Vector2Int topLeft)
    {
        _actions.EnterEdit();
        _actions.SelectEditTile(topLeft);
        _actions.SelectEditTile(new Vector2Int(topLeft.X + 1, topLeft.Y));
        _actions.SelectEditTile(new Vector2Int(topLeft.X, topLeft.Y + 1));
        _actions.SelectEditTile(new Vector2Int(topLeft.X + 1, topLeft.Y + 1));
        return _actions.ConfirmEdit();
    }

    public void Reset() => _actions.ResetEdit();
}
