using System.Runtime.InteropServices;

namespace GamePlaytestHarness;

public partial class Form1 : Form
{
    private const int WmHotkey = 0x0312;
    private const int ModAlt = 0x0001;

    private readonly System.Windows.Forms.Timer _timer;
    private readonly GameAdapter _adapter = new();
    private readonly AimTelemetry _aimTelemetry = new();
    private readonly DecisionLogger _logger = new();
    private readonly RushValidator _rushValidator;
    private readonly ScenarioRunner _runner;
    private readonly FireEventTester _fireTester;

    private DateTime _lastTick = DateTime.UtcNow;

    public Form1()
    {
        InitializeComponent();
        DoubleBuffered = true;

        _rushValidator = new RushValidator(_adapter);
        _runner = new ScenarioRunner(_adapter, _aimTelemetry, _rushValidator, _logger);
        _fireTester = new FireEventTester(_adapter);

        _timer = new System.Windows.Forms.Timer { Interval = 16 };
        _timer.Tick += TimerTick;
        _timer.Start();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        RegisterHotKey(Handle, 100, ModAlt, (uint)Keys.D0);
        RegisterHotKey(Handle, 101, ModAlt, (uint)Keys.D1);
        RegisterHotKey(Handle, 102, ModAlt, (uint)Keys.D2);
        RegisterHotKey(Handle, 109, ModAlt, (uint)Keys.D9);
    }

    protected override void OnHandleDestroyed(EventArgs e)
    {
        foreach (var id in new[] { 100, 101, 102, 109 })
            UnregisterHotKey(Handle, id);

        base.OnHandleDestroyed(e);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WmHotkey)
        {
            switch (m.WParam.ToInt32())
            {
                case 100: _runner.Toggle(); break;
                case 101: _aimTelemetry.OverlayEnabled = !_aimTelemetry.OverlayEnabled; break;
                case 102: _fireTester.LoggingEnabled = !_fireTester.LoggingEnabled; break;
                case 109: _runner.AggressiveProfileEnabled = !_runner.AggressiveProfileEnabled; break;
            }
            Invalidate();
        }

        base.WndProc(ref m);
    }

    private void TimerTick(object? sender, EventArgs e)
    {
        var now = DateTime.UtcNow;
        var dt = (float)(now - _lastTick).TotalSeconds;
        _lastTick = now;

        _adapter.Poll(dt);
        _runner.Tick(dt);
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        var g = e.Graphics;
        var cx = ClientSize.Width / 2f;
        var cy = ClientSize.Height / 2f;

        if (_aimTelemetry.OverlayEnabled)
        {
            var radius = Math.Min(ClientSize.Width, ClientSize.Height) * 0.2f;
            using var pen = new Pen(_aimTelemetry.CurrentCandidate is null ? Color.Lime : Color.Red, 2f);
            g.DrawEllipse(pen, cx - radius, cy - radius, radius * 2, radius * 2);
        }

        using var font = new Font(FontFamily.GenericMonospace, 10f);
        var status = _runner.IsRunning ? "RUNNING" : "IDLE";
        g.DrawString($"Scenario: {_runner.ScenarioName}", font, Brushes.White, 10, 10);
        g.DrawString($"State: {status}", font, Brushes.White, 10, 30);
        g.DrawString($"Elapsed: {_runner.ElapsedSeconds:F2}s", font, Brushes.White, 10, 50);
        g.DrawString(_runner.LastAssertionMessage, font,
            _runner.LastAssertionPassed ? Brushes.Lime : Brushes.Red, 10, 70);
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint key);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
}
