namespace GamePlaytestHarness;

public enum PieceType
{
    Wall, Floor, Ramp, Cone, Roof, Trap
}
