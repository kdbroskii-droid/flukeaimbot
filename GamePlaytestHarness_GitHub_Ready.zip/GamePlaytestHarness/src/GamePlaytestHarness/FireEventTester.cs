namespace GamePlaytestHarness;

public sealed class FireEventTester
{
    private readonly IActionAPI _actions;
    private double _lastFireTime;

    public bool LoggingEnabled { get; set; }
    public double CooldownSeconds { get; set; } = 0.25;
    public int FireCount { get; private set; }

    public FireEventTester(IActionAPI actions) => _actions = actions;

    public bool TryFireTestEvent(double timestampSeconds)
    {
        if (timestampSeconds - _lastFireTime < CooldownSeconds)
            return false;

        _actions.Fire();
        _lastFireTime = timestampSeconds;
        FireCount++;
        return true;
    }
}
