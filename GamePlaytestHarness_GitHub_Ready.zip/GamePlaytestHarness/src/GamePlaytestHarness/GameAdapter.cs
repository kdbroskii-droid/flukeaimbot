using System.Numerics;

namespace GamePlaytestHarness;

public sealed class GameAdapter : IGameState, IActionAPI
{
    private readonly List<ITargetable> _enemies = new();
    private readonly AdapterBuildGrid _buildGrid = new();

    public Vector3 PlayerPosition { get; private set; } = Vector3.Zero;
    public Vector3 PlayerForward { get; private set; } = Vector3.UnitZ;
    public float PlayerHealth { get; private set; } = 100f;
    public float PlayerShield { get; private set; } = 100f;
    public bool IsPlayerAlive { get; private set; } = true;
    public bool IsInStorm { get; private set; }
    public float StormDistance { get; private set; } = 100f;
    public bool HasCover { get; private set; }
    public bool HasHealingItem { get; private set; } = true;
    public bool HasResources { get; private set; } = true;
    public IReadOnlyList<ITargetable> Enemies => _enemies;
    public IBuildGrid BuildGrid => _buildGrid;

    public void Poll(float deltaTime)
    {
        // TODO: Poll your game's public world and controller APIs here.
    }

    public void MoveForward() { /* TODO: PlayerController.Move(InputDir.Forward) */ }
    public void MoveBackward() { /* TODO: PlayerController.Move(InputDir.Backward) */ }
    public void MoveLeft() { /* TODO: PlayerController.Move(InputDir.Left) */ }
    public void MoveRight() { /* TODO: PlayerController.Move(InputDir.Right) */ }
    public void StopMovement() { /* TODO: PlayerController.StopMovement() */ }
    public void Jump() { /* TODO: PlayerController.Jump() */ }
    public void Sprint(bool enabled) { /* TODO: PlayerController.SetSprint(enabled) */ }
    public void Crouch(bool enabled) { /* TODO: PlayerController.SetCrouch(enabled) */ }
    public void SetMoveStyle(MoveStyle style) { /* TODO: PlayerController.SetMoveStyle(style) */ }
    public void Fire() { /* TODO: WeaponController.Fire() */ }
    public void ADS(bool enabled) { /* TODO: WeaponController.SetADS(enabled) */ }
    public void Reload() { /* TODO: WeaponController.Reload() */ }
    public void SelectSlot(int slot) { /* TODO: Inventory.SelectSlot(slot) */ }
    public void SelectWall() { /* TODO: BuildController.SelectPiece(PieceType.Wall) */ }
    public void SelectFloor() { /* TODO: BuildController.SelectPiece(PieceType.Floor) */ }
    public void SelectRamp() { /* TODO: BuildController.SelectPiece(PieceType.Ramp) */ }
    public void SelectCone() { /* TODO: BuildController.SelectPiece(PieceType.Cone) */ }
    public void SelectTrap() { /* TODO: BuildController.SelectPiece(PieceType.Trap) */ }
    public bool PlaceBuild() { /* TODO: return BuildController.TryPlace() */ return true; }
    public void RotateBuild() { /* TODO: BuildController.Rotate() */ }
    public void ChangeMaterial() { /* TODO: BuildController.ChangeMaterial() */ }
    public void EnterEdit() { /* TODO: EditController.Enter() */ }
    public void SelectEditTile(Vector2Int cell) { /* TODO: EditController.SelectTile(cell) */ }
    public bool ConfirmEdit() { /* TODO: return EditController.Confirm() */ return true; }
    public void ResetEdit() { /* TODO: EditController.Reset() */ }
    public void Interact() { /* TODO: PlayerController.Interact() */ }
    public void Pickaxe() { /* TODO: Inventory.EquipPickaxe() */ }

    private sealed class AdapterBuildGrid : IBuildGrid
    {
        public IReadOnlyCollection<PieceType> AvailablePieces => Enum.GetValues<PieceType>();
        public Vector2Int Snap(Vector2Int requestedCell) => requestedCell;
        public bool CanPlace(PieceType pieceType, Vector2Int cell) => true;
        public bool IsOccupied(Vector2Int cell) => false;
    }
}
