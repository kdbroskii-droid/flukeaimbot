namespace GamePlaytestHarness;

public sealed class CombatProbe
{
    private readonly IActionAPI _actions;
    public CombatProbe(IActionAPI actions) => _actions = actions;

    public void SelectWeapon(int slot) => _actions.SelectSlot(slot);
    public void SetAds(bool enabled) => _actions.ADS(enabled);
    public void Reload() => _actions.Reload();
    public void FireTestEvent() => _actions.Fire();
}
