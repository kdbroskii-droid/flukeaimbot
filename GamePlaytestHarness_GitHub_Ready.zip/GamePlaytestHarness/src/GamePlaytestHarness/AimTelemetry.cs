using System.Numerics;

namespace GamePlaytestHarness;

public sealed class AimTelemetry
{
    public float FovRadiusDegrees { get; set; } = 20f;
    public float MaxRange { get; set; } = 150f;
    public ITargetable? CurrentCandidate { get; private set; }
    public float CurrentAngle { get; private set; }
    public string LastDecision { get; private set; } = "No target evaluated.";
    public bool OverlayEnabled { get; set; } = true;

    public void Update(Context context)
    {
        CurrentCandidate = null;

        if (context.NearestEnemy is null)
        {
            LastDecision = "Rejected: no alive target.";
            return;
        }

        var target = context.NearestEnemy;
        var distance = Vector3.Distance(context.PlayerPosition, target.AimPoint);

        if (!target.IsVisible)
        {
            LastDecision = "Rejected: line of sight unavailable.";
            return;
        }

        if (distance > MaxRange)
        {
            LastDecision = $"Rejected: range {distance:F1} > {MaxRange:F1}.";
            return;
        }

        var direction = Vector3.Normalize(target.AimPoint - context.PlayerPosition);
        var forward = Vector3.Normalize(context.PlayerForward);
        var dot = Math.Clamp(Vector3.Dot(forward, direction), -1f, 1f);
        CurrentAngle = MathF.Acos(dot) * 180f / MathF.PI;

        if (CurrentAngle > FovRadiusDegrees)
        {
            LastDecision = $"Rejected: angle {CurrentAngle:F2}° outside FOV.";
            return;
        }

        CurrentCandidate = target;
        LastDecision = $"Accepted: range={distance:F1}, angle={CurrentAngle:F2}°.";
    }
}
