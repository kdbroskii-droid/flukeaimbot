namespace GamePlaytestHarness;

public sealed class ScenarioRunner
{
    private readonly GameAdapter _adapter;
    private readonly AimTelemetry _aimTelemetry;
    private readonly RushValidator _rushValidator;
    private readonly DecisionLogger _logger;

    public bool IsRunning { get; private set; }
    public bool AggressiveProfileEnabled { get; set; }
    public string ScenarioName { get; private set; } = "Default QA Scenario";
    public double ElapsedSeconds { get; private set; }
    public bool LastAssertionPassed { get; private set; } = true;
    public string LastAssertionMessage { get; private set; } = "Idle.";

    public ScenarioRunner(GameAdapter adapter, AimTelemetry aimTelemetry, RushValidator rushValidator, DecisionLogger logger)
    {
        _adapter = adapter;
        _aimTelemetry = aimTelemetry;
        _rushValidator = rushValidator;
        _logger = logger;
    }

    public void Toggle()
    {
        IsRunning = !IsRunning;
        if (IsRunning)
        {
            ElapsedSeconds = 0;
            LastAssertionMessage = "Scenario started.";
        }
        else
        {
            _adapter.StopMovement();
            _adapter.Sprint(false);
            LastAssertionMessage = "Scenario stopped.";
        }
    }

    public void Tick(float deltaTime)
    {
        if (!IsRunning)
            return;

        ElapsedSeconds += deltaTime;
        var context = Context.FromGameState(_adapter, ElapsedSeconds);
        _aimTelemetry.Update(context);

        if (AggressiveProfileEnabled)
            _rushValidator.Tick(context);

        LastAssertionPassed = context.IsPlayerAlive;
        LastAssertionMessage = _aimTelemetry.LastDecision;
        _logger.Log(context.TimestampSeconds, ScenarioName, "Tick", LastAssertionMessage);
    }
}
