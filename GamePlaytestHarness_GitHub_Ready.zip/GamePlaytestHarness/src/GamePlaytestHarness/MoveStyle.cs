namespace GamePlaytestHarness;

public enum MoveStyle
{
    Auto, Walk, Sprint, Crouch, StrafeLeft, StrafeRight
}
