using System.Text;

namespace GamePlaytestHarness;

public sealed class DecisionLogger
{
    private readonly List<string> _rows = new();

    public void Log(double timestamp, string scenario, string decision, string result)
    {
        _rows.Add($"{timestamp:F3},\"{scenario.Replace("\"", "\"\"")}\",\"{decision.Replace("\"", "\"\"")}\",\"{result.Replace("\"", "\"\"")}\"");
    }

    public void Clear() => _rows.Clear();

    public void WriteCsv(string path)
    {
        File.WriteAllText(path, "Timestamp,Scenario,Decision,Result\n" + string.Join("\n", _rows));
    }
}
