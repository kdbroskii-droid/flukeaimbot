using System.Numerics;

namespace GamePlaytestHarness;

public interface IGameState
{
    Vector3 PlayerPosition { get; }
    Vector3 PlayerForward { get; }
    float PlayerHealth { get; }
    float PlayerShield { get; }
    bool IsPlayerAlive { get; }
    bool IsInStorm { get; }
    float StormDistance { get; }
    bool HasCover { get; }
    bool HasHealingItem { get; }
    bool HasResources { get; }
    IReadOnlyList<ITargetable> Enemies { get; }
    IBuildGrid BuildGrid { get; }
}
