using System.Numerics;

namespace GamePlaytestHarness;

public interface ITargetable
{
    string Id { get; }
    Vector3 WorldPosition { get; }
    Vector3 AimPoint { get; }
    bool IsAlive { get; }
    bool IsVisible { get; }
}
