using System.Numerics;

namespace GamePlaytestHarness;

public sealed class Context
{
    public double TimestampSeconds { get; init; }
    public Vector3 PlayerPosition { get; init; }
    public Vector3 PlayerForward { get; init; }
    public float PlayerHealth { get; init; }
    public ITargetable? NearestEnemy { get; init; }
    public float NearestEnemyDistance { get; init; }
    public float ThreatLevel { get; init; }

    public static Context FromGameState(IGameState state, double timestamp)
    {
        var enemy = state.Enemies.Where(x => x.IsAlive)
            .OrderBy(x => Vector3.Distance(state.PlayerPosition, x.WorldPosition))
            .FirstOrDefault();

        var distance = enemy is null ? float.MaxValue :
            Vector3.Distance(state.PlayerPosition, enemy.WorldPosition);

        return new Context
        {
            TimestampSeconds = timestamp,
            PlayerPosition = state.PlayerPosition,
            PlayerForward = state.PlayerForward,
            PlayerHealth = state.PlayerHealth,
            NearestEnemy = enemy,
            NearestEnemyDistance = distance,
            ThreatLevel = enemy is null ? 0f : Math.Clamp(1f - distance / 100f, 0f, 1f)
        };
    }
}
