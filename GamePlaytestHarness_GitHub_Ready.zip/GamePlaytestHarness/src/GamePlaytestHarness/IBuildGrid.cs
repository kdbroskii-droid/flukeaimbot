namespace GamePlaytestHarness;

public interface IBuildGrid
{
    Vector2Int Snap(Vector2Int requestedCell);
    bool CanPlace(PieceType pieceType, Vector2Int cell);
    bool IsOccupied(Vector2Int cell);
    IReadOnlyCollection<PieceType> AvailablePieces { get; }
}
