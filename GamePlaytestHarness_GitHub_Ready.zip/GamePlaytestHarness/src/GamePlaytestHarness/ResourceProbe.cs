namespace GamePlaytestHarness;

public sealed class ResourceProbe
{
    public bool ValidateResources(IGameState state) => state.HasResources;
    public bool ValidateHealing(IGameState state) => state.HasHealingItem;
}
