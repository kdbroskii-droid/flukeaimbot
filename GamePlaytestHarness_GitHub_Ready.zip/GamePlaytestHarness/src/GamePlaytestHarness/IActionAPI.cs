namespace GamePlaytestHarness;

public interface IActionAPI
{
    void MoveForward();
    void MoveBackward();
    void MoveLeft();
    void MoveRight();
    void StopMovement();
    void Jump();
    void Sprint(bool enabled);
    void Crouch(bool enabled);
    void SetMoveStyle(MoveStyle style);
    void Fire();
    void ADS(bool enabled);
    void Reload();
    void SelectSlot(int slot);
    void SelectWall();
    void SelectFloor();
    void SelectRamp();
    void SelectCone();
    void SelectTrap();
    bool PlaceBuild();
    void RotateBuild();
    void ChangeMaterial();
    void EnterEdit();
    void SelectEditTile(Vector2Int cell);
    bool ConfirmEdit();
    void ResetEdit();
    void Interact();
    void Pickaxe();
}
