namespace GamePlaytestHarness;

public sealed class BuildValidator
{
    private readonly IActionAPI _actions;
    private readonly IGameState _state;

    public BuildValidator(IActionAPI actions, IGameState state)
    {
        _actions = actions;
        _state = state;
    }

    public bool ValidatePlacement(PieceType pieceType, Vector2Int cell)
    {
        var snapped = _state.BuildGrid.Snap(cell);
        if (!_state.BuildGrid.CanPlace(pieceType, snapped))
            return false;

        switch (pieceType)
        {
            case PieceType.Wall: _actions.SelectWall(); break;
            case PieceType.Floor: _actions.SelectFloor(); break;
            case PieceType.Ramp: _actions.SelectRamp(); break;
            case PieceType.Cone:
            case PieceType.Roof: _actions.SelectCone(); break;
            case PieceType.Trap: _actions.SelectTrap(); break;
        }

        return _actions.PlaceBuild();
    }
}
